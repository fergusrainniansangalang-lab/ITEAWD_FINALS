/**
 * products.js
 * ============================================================
 * Comprehensive Japanese-Themed Product Catalog
 * 5 authentic Japanese products for each of the 7 required categories:
 * 1. Clothing (5)
 * 2. Grocery / Foods (5)
 * 3. Electronics (5)
 * 4. Shoes (5)
 * 5. Cleaning Supplies / Home Goods (5)
 * 6. Sports Equipment / Sports & Outdoors (5)
 * 7. Books (5)
 * Total: 35 items
 * ============================================================
 */

export const products = [
  // ─────────────────────────────────────────────────────────────
  // 1. CLOTHING (衣類) - 5 Japanese Apparel Products
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-cloth-1',
    name: 'Flannel Shirt',
    category: 'clothing',
    categoryName: 'Clothing',
    price: 1850.00,
    originalPrice: 2200.00,
    rating: 4.9,
    reviewsCount: 342,
    image: '/images/products/clothing/Flannel Shirt.avif',
    images: ['/images/products/clothing/Flannel Shirt.avif'],
    description: 'Classic Japanese brushed cotton flannel shirt designed for comfortable layering with timeless button-down styling.',
    features: ['100% Ultra-soft Brushed Cotton', 'Button-Down Collar & Front Placket', 'Relaxed Daily Wear Fit', 'Japanese Tailored Stitching'],
    inStock: true,
    sku: 'RJK-CL-001',
    isFeatured: true,
    badge: 'Trending in Tokyo'
  },
  {
    id: 'prod-cloth-2',
    name: 'Heavy Weight Sweat Cocoon',
    category: 'clothing',
    categoryName: 'Clothing',
    price: 2450.00,
    originalPrice: 2900.00,
    rating: 4.8,
    reviewsCount: 189,
    image: '/images/products/clothing/Heavy Weight Sweat Cocoon.avif',
    images: ['/images/products/clothing/Heavy Weight Sweat Cocoon.avif'],
    description: 'Heavyweight loopback cotton pullover hoodie with a cocoon silhouette for relaxed Japanese street fashion.',
    features: ['Heavyweight 380 GSM Cotton', 'Cocoon Oversized Silhouette', 'Kangaroo Pockets', 'Double-layered Warm Hood'],
    inStock: true,
    sku: 'RJK-CL-002',
    isFeatured: false,
    badge: 'Streetwear'
  },
  {
    id: 'prod-cloth-3',
    name: 'Ribbed Beanie',
    category: 'clothing',
    categoryName: 'Clothing',
    price: 650.00,
    originalPrice: 850.00,
    rating: 4.9,
    reviewsCount: 297,
    image: '/images/products/clothing/Ribbed Beanie.avif',
    images: ['/images/products/clothing/Ribbed Beanie.avif'],
    description: 'Cozy fine-knit ribbed beanie made from thermal spun yarn. Designed to keep warmth while pairing with any winter wardrobe.',
    features: ['Fine Ribbed Knit Construction', 'Thermal Insulation Yarn', 'Folded Cuff Detail', 'Unisex One-Size-Fits-All'],
    inStock: true,
    sku: 'RJK-CL-003',
    isFeatured: false,
    badge: 'Popular'
  },
  {
    id: 'prod-cloth-4',
    name: 'Straight Jeans',
    category: 'clothing',
    categoryName: 'Clothing',
    price: 2690.00,
    originalPrice: 3200.00,
    rating: 4.8,
    reviewsCount: 421,
    image: '/images/products/clothing/Straight Jeans.avif',
    images: ['/images/products/clothing/Straight Jeans.avif'],
    description: 'Timeless Japanese straight-leg denim jeans with clean rinse wash, durable copper rivets, and five-pocket utility styling.',
    features: ['100% Premium Cotton Denim', 'Classic Straight Leg Fit', 'Reinforced Rivet Details', 'Authentic Japanese Indigo Wash'],
    inStock: true,
    sku: 'RJK-CL-004',
    isFeatured: false,
    badge: 'Essential'
  },
  {
    id: 'prod-cloth-5',
    name: 'Sweat Look Knit Oversized Pullover',
    category: 'clothing',
    categoryName: 'Clothing',
    price: 2290.00,
    originalPrice: 2750.00,
    rating: 4.9,
    reviewsCount: 156,
    image: '/images/products/clothing/Sweat Look Knit Oversized Pullover.avif',
    images: ['/images/products/clothing/Sweat Look Knit Oversized Pullover.avif'],
    description: 'Blends the comfort of a sweatshirt with the texture of a luxury knit pullover. Ideal for casual, cozy elegance.',
    features: ['Sweatshirt-Inspired Knit Texture', 'Oversized Boxy Silhouette', 'Ribbed Hem and Cuffs', 'Ultra-soft Non-itch Blend'],
    inStock: true,
    sku: 'RJK-CL-005',
    isFeatured: false,
    badge: 'New Arrival'
  },

  // ─────────────────────────────────────────────────────────────
  // 2. GROCERY / FOODS (食品) - 5 Japanese Culinary Products
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-groc-1',
    name: 'Certified Organic Green Yuzu Kosho Paste',
    category: 'grocery',
    categoryName: 'Grocery',
    price: 680.00,
    originalPrice: 820.00,
    rating: 4.9,
    reviewsCount: 652,
    image: '/images/products/grocery/Certified Organic Green Yuzu Kosho Paste.webp',
    images: ['/images/products/grocery/Certified Organic Green Yuzu Kosho Paste.webp'],
    description: 'Authentic Japanese citrus chili seasoning made from stone-crushed green yuzu citrus peel and fiery green chili peppers with natural sea salt.',
    features: ['100% Certified Organic Japanese Green Yuzu', 'Stone-Crushed Spicy Pepper Blend', 'Natural Mineral Sea Salt', 'Versatile Condiment for Meat, Fish & Soup'],
    inStock: true,
    sku: 'RJK-FD-101',
    isFeatured: true,
    badge: 'Best Seller'
  },
  {
    id: 'prod-groc-2',
    name: 'J Taste Dried Hijiki Seaweed Premium',
    category: 'grocery',
    categoryName: 'Grocery',
    price: 1150.00,
    originalPrice: 1400.00,
    rating: 5.0,
    reviewsCount: 284,
    image: '/images/products/grocery/J Taste Dried Hijiki Seaweed Premium.webp',
    images: ['/images/products/grocery/J Taste Dried Hijiki Seaweed Premium.webp'],
    description: 'Premium quality sun-dried Japanese wild Hijiki seaweed packed with dietary fiber, iron, calcium, and deep ocean minerals.',
    features: ['Wild Harvested Japanese Hijiki Seaweed', 'Rich in Essential Minerals & Iron', 'Natural Sun-Dried Preservation', 'Easy 20-Minute Rehydration for Salads'],
    inStock: true,
    sku: 'RJK-FD-102',
    isFeatured: false,
    badge: 'Top Rated'
  },
  {
    id: 'prod-groc-3',
    name: 'Ichiran Hakata Tonkotsu Ramen Master Home Kit',
    category: 'grocery',
    categoryName: 'Grocery',
    price: 890.00,
    originalPrice: 1050.00,
    rating: 4.8,
    reviewsCount: 512,
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Experience the world-renowned Fukuoka Hakata tonkotsu broth at home. Includes firm straight noodles and Ichiran proprietary red seasoning powder.',
    features: ['5 Full Servings per Box', 'Authentic Fukuoka Tonkotsu Base', 'Original Secret Red Pepper Seasoning', 'Ready in 3 Minutes'],
    inStock: true,
    sku: 'RJK-FD-103',
    isFeatured: false,
    badge: 'Must Try'
  },
  {
    id: 'prod-groc-4',
    name: 'Tokyo Tokyo Banana & Pocky Japanese Snack Crate',
    category: 'grocery',
    categoryName: 'Grocery',
    price: 1250.00,
    originalPrice: 1500.00,
    rating: 4.9,
    reviewsCount: 378,
    image: 'https://images.unsplash.com/photo-1582293041079-7814c2f12063?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1582293041079-7814c2f12063?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Curated gift box with 15 limited edition Japanese treats: Tokyo Banana sponge cakes, Sakura Matcha KitKats, Strawberry Pocky, and salty Senbei crackers.',
    features: ['15 Assorted Authentic Japanese Snacks', 'Limited Seasonal Sakura Editions', 'Direct Import from Tokyo Confectioneries', 'Custom Decorative Gift Box'],
    inStock: true,
    sku: 'RJK-FD-104',
    isFeatured: false,
    badge: 'Gift Choice'
  },
  {
    id: 'prod-groc-5',
    name: 'Kagoshima A5 Wagyu Dashi & Furikake Rice Seasoning',
    category: 'grocery',
    categoryName: 'Grocery',
    price: 740.00,
    originalPrice: 890.00,
    rating: 4.7,
    reviewsCount: 165,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Gourmet crispy rice topping infused with real freeze-dried Kagoshima A5 Wagyu beef bits, toasted sesame, and kombu seaweed umami crunch.',
    features: ['Real A5 Japanese Wagyu Beef Flakes', 'Kombu Kelp & Bonito Umami Profile', 'No Artificial Preservatives', 'Elevates Rice, Noodles & Salads'],
    inStock: true,
    sku: 'RJK-FD-105',
    isFeatured: false,
    badge: 'Gourmet'
  },

  // ─────────────────────────────────────────────────────────────
  // 3. ELECTRONICS (電子機器) - 5 Japanese Tech Innovations
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-elec-1',
    name: 'Sony WH-1000XM5 Hi-Res Noise-Cancelling Headphones',
    category: 'electronics',
    categoryName: 'Electronics',
    price: 18990.00,
    originalPrice: 20990.00,
    rating: 4.9,
    reviewsCount: 890,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Engineered in Tokyo with dual processors and 8 microphones for industry-leading noise cancellation, LDAC Hi-Res Wireless, and 30-hour battery life.',
    features: ['Integrated Processor V1 + QN1', 'Auto NC Optimizer & 8 Microphones', 'Ultra-comfortable Lightweight Design', 'Speak-to-Chat & Multipoint Connection'],
    inStock: true,
    sku: 'RJK-EL-201',
    isFeatured: false,
    badge: 'Award Winner'
  },
  {
    id: 'prod-elec-2',
    name: 'Nintendo Switch OLED Model Mario Red Edition',
    category: 'electronics',
    categoryName: 'Electronics',
    price: 16490.00,
    originalPrice: 17990.00,
    rating: 5.0,
    reviewsCount: 1120,
    image: 'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Kyoto-crafted handheld gaming console with a vibrant 7-inch OLED screen, wide adjustable stand, enhanced audio, and 64GB internal storage.',
    features: ['7-inch Vibrant OLED Screen', 'Wide Adjustable Stand for Tabletop Mode', 'Wired LAN Port in Dock', 'Enhanced Onboard Audio'],
    inStock: true,
    sku: 'RJK-EL-202',
    isFeatured: false,
    badge: 'Hot Seller'
  },
  {
    id: 'prod-elec-3',
    name: 'Zojirushi Neuro Fuzzy Micom Smart Rice Cooker 1.0L',
    category: 'electronics',
    categoryName: 'Electronics',
    price: 11990.00,
    originalPrice: 13500.00,
    rating: 4.9,
    reviewsCount: 420,
    image: 'https://images.unsplash.com/photo-1585515320310-259814833e62?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1585515320310-259814833e62?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Made in Japan. Features advanced Neuro Fuzzy logic technology that micro-adjusts temperature and heating time for flawless Japanese rice every batch.',
    features: ['Made in Japan with Neuro Fuzzy Tech', 'Multiple Settings: White, Sushi, Porridge', 'Spherical Inner Cooking Pan & Heating', 'Keep Warm & Reheat Functions'],
    inStock: true,
    sku: 'RJK-EL-203',
    isFeatured: false,
    badge: 'Chef Choice'
  },
  {
    id: 'prod-elec-4',
    name: 'Audio-Technica AT-LP120XUSB Direct-Drive Turntable',
    category: 'electronics',
    categoryName: 'Electronics',
    price: 17800.00,
    originalPrice: 19500.00,
    rating: 4.8,
    reviewsCount: 231,
    image: 'https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Tokyo precision audio engineering. Direct-drive DC servo motor with selectable phono pre-amplifier and USB output to digitize vinyl records.',
    features: ['Direct-drive High-torque DC Motor', 'AT-VM95E Dual Magnet Cartridge', 'Built-in Switchable Phono Pre-amp', 'USB Output for Direct PC Recording'],
    inStock: true,
    sku: 'RJK-EL-204',
    isFeatured: false,
    badge: 'Audiophile'
  },
  {
    id: 'prod-elec-5',
    name: 'Panasonic Nanoe Moisture Infusion Hair Dryer EH-NA65',
    category: 'electronics',
    categoryName: 'Electronics',
    price: 6490.00,
    originalPrice: 7200.00,
    rating: 4.8,
    reviewsCount: 310,
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Patented Japanese Nanoe moisture technology pulls water molecules from the air, infusing 1,000x more moisture into hair while drying.',
    features: ['Nanoe Moisture Particle Generator', 'Quick-dry Nozzle for Fast Uniform Airflow', '3 Speed & 3 Temperature Modes', 'Cold-shot Button to Lock Hairstyle'],
    inStock: true,
    sku: 'RJK-EL-205',
    isFeatured: false,
    badge: 'Beauty Tech'
  },

  // ─────────────────────────────────────────────────────────────
  // 4. SHOES (履物) - 5 Japanese Footwear Products
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-shoe-1',
    name: 'Color Canvas Sneakers',
    category: 'shoes',
    categoryName: 'Shoes',
    price: 1990.00,
    originalPrice: 2490.00,
    rating: 4.9,
    reviewsCount: 468,
    image: '/images/products/shoes/Color Canvas Sneakers.avif',
    images: ['/images/products/shoes/Color Canvas Sneakers.avif'],
    description: 'Vibrant Japanese street-style low-cut canvas sneakers featuring cushioned insole and vulcanized rubber sole.',
    features: ['100% Heavy Cotton Canvas Upper', 'Durable Vulcanized Rubber Sole', 'Cushioned Memory Foam Footbed', 'Japanese Minimalist Design'],
    inStock: true,
    sku: 'RJK-SH-301',
    isFeatured: true,
    badge: 'Popular'
  },
  {
    id: 'prod-shoe-2',
    name: 'Faux Mouton Short Boots',
    category: 'shoes',
    categoryName: 'Shoes',
    price: 3490.00,
    originalPrice: 3990.00,
    rating: 4.9,
    reviewsCount: 520,
    image: '/images/products/shoes/Faux Mouton Short Boots.avif',
    images: ['/images/products/shoes/Faux Mouton Short Boots.avif'],
    description: 'Ultra-warm short winter ankle boots lined with plush faux mouton fleece for lightweight cold-weather comfort.',
    features: ['Soft Faux Mouton Fleece Lining', 'Water-Resistant Suede Texture Upper', 'Anti-Slip Tread Outsole', 'Slip-On Ankle Height Silhouette'],
    inStock: true,
    sku: 'RJK-SH-302',
    isFeatured: false,
    badge: 'Winter Special'
  },
  {
    id: 'prod-shoe-3',
    name: 'Nylon Combination Flat Sole Sneakers',
    category: 'shoes',
    categoryName: 'Shoes',
    price: 2890.00,
    originalPrice: 3400.00,
    rating: 4.8,
    reviewsCount: 198,
    image: '/images/products/shoes/Nylon Combination Flat Sole Sneakers.avif',
    images: ['/images/products/shoes/Nylon Combination Flat Sole Sneakers.avif'],
    description: 'Low-profile athletic sneakers crafted with hybrid technical nylon and supple overlays for effortless city walking.',
    features: ['Technical Nylon & Synthetic Leather Combo', 'Flat Low-Profile Rubber Grip Sole', 'Breathable Mesh Tongue & Insole', 'Casual Urban Commuter Styling'],
    inStock: true,
    sku: 'RJK-SH-303',
    isFeatured: false,
    badge: 'Urban Walk'
  },
  {
    id: 'prod-shoe-4',
    name: 'High Top Sneakers',
    category: 'shoes',
    categoryName: 'Shoes',
    price: 2450.00,
    originalPrice: 2850.00,
    rating: 4.7,
    reviewsCount: 185,
    image: '/images/products/shoes/High Top Sneakers.avif',
    images: ['/images/products/shoes/High Top Sneakers.avif'],
    description: 'Vintage-inspired Japanese high-top canvas sneakers with reinforced toe cap and contrast stitching.',
    features: ['Durable 16oz Cotton Canvas', 'Reinforced Rubber Toe Guard', 'High Ankle Support Cushioning', 'Signature Japanese Craftsmanship'],
    inStock: true,
    sku: 'RJK-SH-304',
    isFeatured: false,
    badge: 'Classic'
  },
  {
    id: 'prod-shoe-5',
    name: 'Coin Loafers',
    category: 'shoes',
    categoryName: 'Shoes',
    price: 3690.00,
    originalPrice: 4200.00,
    rating: 4.8,
    reviewsCount: 142,
    image: '/images/products/shoes/Coin Loafers.avif',
    images: ['/images/products/shoes/Coin Loafers.avif'],
    description: 'Classic Japanese penny loafers crafted from smooth polished leather with saddle strap slot and dress sole.',
    features: ['Polished Smooth Vegan Leather', 'Traditional Penny Saddle Strap Slot', 'Comfort Padded Footbed', 'Versatile Formal to Casual Style'],
    inStock: true,
    sku: 'RJK-SH-305',
    isFeatured: false,
    badge: 'Artisan Crafted'
  },

  // ─────────────────────────────────────────────────────────────
  // 5. CLEANING SUPPLIES / HOME GOODS (生活・清掃) - 5 Products
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-clean-1',
    name: 'Chaise Longue',
    category: 'cleaning',
    categoryName: 'Cleaning Supplies',
    price: 4990.00,
    originalPrice: 5990.00,
    rating: 4.9,
    reviewsCount: 780,
    image: '/images/products/cleaning/Chaise longue.avif',
    images: ['/images/products/cleaning/Chaise longue.avif'],
    description: 'Modern Japanese minimalist reclining chaise longue designed for ergonomic relaxation and streamlined living spaces.',
    features: ['Ergonomic Contoured Lounge Structure', 'Breathable Textured Upholstery Fabric', 'Minimalist Sturdy Steel Frame', 'Easy Maintenance Removable Cover'],
    inStock: true,
    sku: 'RJK-CL-401',
    isFeatured: false,
    badge: 'Popular'
  },
  {
    id: 'prod-clean-2',
    name: 'Glostad Foot Stool',
    category: 'cleaning',
    categoryName: 'Cleaning Supplies',
    price: 1890.00,
    originalPrice: 2200.00,
    rating: 4.8,
    reviewsCount: 215,
    image: '/images/products/cleaning/Glostad Foot Stool.avif',
    images: ['/images/products/cleaning/Glostad Foot Stool.avif'],
    description: 'Compact upholstered footstool and ottoman offering flexible seating, clean lines, and soft cushioned support.',
    features: ['High-Resilience Foam Cushion', 'Durable Compact Form Factor', 'Sturdy Solid Support Legs', 'Multipurpose Seating or Footrest'],
    inStock: true,
    sku: 'RJK-CL-402',
    isFeatured: false,
    badge: 'Home Comfort'
  },
  {
    id: 'prod-clean-3',
    name: 'Laundry Bag with Castors',
    category: 'cleaning',
    categoryName: 'Cleaning Supplies',
    price: 1250.00,
    originalPrice: 1500.00,
    rating: 4.9,
    reviewsCount: 164,
    image: '/images/products/cleaning/Laundry bag with castors.avif',
    images: ['/images/products/cleaning/Laundry bag with castors.avif'],
    description: 'Heavy-duty mobile laundry hamper cart equipped with smooth-gliding castors and moisture-resistant liner.',
    features: ['360-Degree Smooth Swivel Wheels', 'Heavy-Duty Moisture Resistant Fabric', 'Sturdy Coated Metal Frame', 'Removable Washable Hamper Bag'],
    inStock: true,
    sku: 'RJK-CL-403',
    isFeatured: false,
    badge: 'Utility'
  },
  {
    id: 'prod-clean-4',
    name: 'LED Table & Wall Lamp',
    category: 'cleaning',
    categoryName: 'Cleaning Supplies',
    price: 1450.00,
    originalPrice: 1790.00,
    rating: 4.7,
    reviewsCount: 390,
    image: '/images/products/cleaning/LED table_wall lamp.avif',
    images: ['/images/products/cleaning/LED table_wall lamp.avif'],
    description: 'Dual-purpose Japanese LED lamp that mounts seamlessly to walls or rests gracefully on desks and bedside tables.',
    features: ['Dual-Use Wall Mount or Table Stand', 'Soft Warm White Eye-Care LED', 'Touch-Sensitive Dimming Control', 'Energy Efficient Minimalist Aesthetic'],
    inStock: true,
    sku: 'RJK-CL-404',
    isFeatured: false,
    badge: 'Modern Deco'
  },
  {
    id: 'prod-clean-5',
    name: 'Shelving Unit',
    category: 'cleaning',
    categoryName: 'Cleaning Supplies',
    price: 2450.00,
    originalPrice: 2900.00,
    rating: 4.9,
    reviewsCount: 110,
    image: '/images/products/cleaning/Shelving unit.avif',
    images: ['/images/products/cleaning/Shelving unit.avif'],
    description: 'Multi-tier open shelving organizer designed for living rooms, kitchens, and home storage utility.',
    features: ['Multi-Tier Open Grid Shelving', 'High Load-Bearing Capacity', 'Rust-Resistant Powder Coating', 'Modular Space-Saving Geometry'],
    inStock: true,
    sku: 'RJK-CL-405',
    isFeatured: false,
    badge: 'Organizer'
  },

  // ─────────────────────────────────────────────────────────────
  // 6. SPORTS EQUIPMENT (スポーツ用品) - 5 Japanese Sports Gear
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-sport-1',
    name: 'Molten BG5000 FIBA Official Japanese Match Basketball',
    category: 'sports',
    categoryName: 'Sports Equipment',
    price: 5490.00,
    originalPrice: 6200.00,
    rating: 5.0,
    reviewsCount: 390,
    image: 'https://images.unsplash.com/photo-1519766304817-4f37bda74a29?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1519766304817-4f37bda74a29?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Hiroshima engineered top-grain natural leather game ball. Features signature 12-panel design with enhanced sweat-absorbing pebble texture.',
    features: ['FIBA Approved Game Ball', 'Genuine Premium Japanese Leather', 'Dual-Cushion Foam Backing', 'Optimal Tactile Moisture Control'],
    inStock: true,
    sku: 'RJK-SP-501',
    isFeatured: false,
    badge: 'FIBA Approved'
  },
  {
    id: 'prod-sport-2',
    name: 'Authentic Keishin Handcrafted Kendo Shinai Bamboo Sword',
    category: 'sports',
    categoryName: 'Sports Equipment',
    price: 2450.00,
    originalPrice: 2900.00,
    rating: 4.9,
    reviewsCount: 145,
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Selected Kyoto Madake 4-stave bamboo with deluxe cowhide leather fittings and Tsuba hand guard. Balanced for tournament and dojo training.',
    features: ['4-Stave Seasoned Madake Bamboo', 'Tournament Standard Size 39 (Men/Women)', 'Hand-stitched White Cowhide Fittings', 'Includes Tsuba & Rubber Dome Ring'],
    inStock: true,
    sku: 'RJK-SP-502',
    isFeatured: false,
    badge: 'Martial Arts'
  },
  {
    id: 'prod-sport-3',
    name: 'Butterfly Viscaria Arylate-Carbon Table Tennis Racket',
    category: 'sports',
    categoryName: 'Sports Equipment',
    price: 8490.00,
    originalPrice: 9600.00,
    rating: 4.9,
    reviewsCount: 278,
    image: 'https://images.unsplash.com/photo-1534158914592-062992fbe900?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1534158914592-062992fbe900?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Manufactured in Saitama, Japan. The world championship standard blade combining carbon speed with ALC softness for explosive spin and touch.',
    features: ['5-Ply Wood + 2-Ply Arylate Carbon', 'Dignics 05 Professional Rubber', 'FL Concave Ergonomic Handle', 'Official ITTF Match Stamp'],
    inStock: true,
    sku: 'RJK-SP-503',
    isFeatured: false,
    badge: 'Championship'
  },
  {
    id: 'prod-sport-4',
    name: 'Mizuno Fortius Tour-V Japanese Badminton Racket Set',
    category: 'sports',
    categoryName: 'Sports Equipment',
    price: 4990.00,
    originalPrice: 5800.00,
    rating: 4.8,
    reviewsCount: 182,
    image: 'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'High-modulus carbon frame with Torayca M40J Japanese graphite. Delivers pinpoint smash accuracy and agile defense responses.',
    features: ['Torayca M40J Japanese Carbon Fiber', 'Even Balance 4U Weight (83g)', 'Aero Groove Frame Drag Reduction', 'Includes Thermal Carry Bag & Shuttles'],
    inStock: true,
    sku: 'RJK-SP-504',
    isFeatured: false,
    badge: 'High Speed'
  },
  {
    id: 'prod-sport-5',
    name: 'Nambu Tekki Japanese Cast Iron Kettlebell 16kg',
    category: 'sports',
    categoryName: 'Sports Equipment',
    price: 3890.00,
    originalPrice: 4500.00,
    rating: 4.9,
    reviewsCount: 94,
    image: 'https://images.unsplash.com/photo-1586401100295-7a8096fd231a?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1586401100295-7a8096fd231a?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Cast in Iwate Prefecture using 900-year-old Nambu iron methods. Ergonomic wide handle with unglazed matte grip for kettlebell swings and snatches.',
    features: ['Traditional Iwate Cast Iron Pour', 'Machined Flat Base for Stability', 'Smooth Non-abrasive Handle Grip', 'Rust-resistant Natural Urushi Coating'],
    inStock: true,
    sku: 'RJK-SP-505',
    isFeatured: false,
    badge: 'Heavy Duty'
  },

  // ─────────────────────────────────────────────────────────────
  // 7. BOOKS (書籍) - 5 Japanese Culture & Literature Books
  // ─────────────────────────────────────────────────────────────
  {
    id: 'prod-book-1',
    name: 'The Art of Washoku: Master Secrets of Japanese Home Cooking',
    category: 'books',
    categoryName: 'Books',
    price: 1290.00,
    originalPrice: 1550.00,
    rating: 4.9,
    reviewsCount: 310,
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Hardcover culinary guide to seasonal Japanese cooking, Dashi preparation, sashimi slicing knives, and UNESCO Intangible Cultural Heritage recipes.',
    features: ['Hardcover 320 Full-Color Pages', '120 Step-by-Step Authentic Recipes', 'Guide to Seasonal Ingredients & Umami', 'Foreword by Michelin 3-Star Master Chef'],
    inStock: true,
    sku: 'RJK-BK-601',
    isFeatured: false,
    badge: 'Culinary Masterpiece'
  },
  {
    id: 'prod-book-2',
    name: 'Genki: An Integrated Course in Elementary Japanese (3rd Edition)',
    category: 'books',
    categoryName: 'Books',
    price: 1890.00,
    originalPrice: 2200.00,
    rating: 5.0,
    reviewsCount: 940,
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'The premier worldwide standard for learning Japanese. Complete textbook and workbook covering Hiragana, Katakana, Kanji, grammar, and audio dialogues.',
    features: ['Complete 3rd Edition with Digital Audio App', '23 Comprehensive Cultural Dialogue Units', '317 Essential Kanji with Stroke Orders', 'Includes Full Exercise Answer Key'],
    inStock: true,
    sku: 'RJK-BK-602',
    isFeatured: false,
    badge: 'Bestseller'
  },
  {
    id: 'prod-book-3',
    name: 'Masterpieces of Japanese Ukiyo-e Woodblock Prints (Folio Edition)',
    category: 'books',
    categoryName: 'Books',
    price: 2650.00,
    originalPrice: 3100.00,
    rating: 4.9,
    reviewsCount: 167,
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Deluxe slipcased art folio compiling 200 rare woodblock prints by Hokusai, Hiroshige, and Utamaro with historical essays and color commentary.',
    features: ['Large Format Coffee Table Hardcover', 'Gold Foil Stamped Cloth Slipcase', 'High-definition 1200 DPI Restorations', 'Biographies of Edo-Period Print Masters'],
    inStock: true,
    sku: 'RJK-BK-603',
    isFeatured: false,
    badge: 'Collector Edition'
  },
  {
    id: 'prod-book-4',
    name: 'The Book of Tea by Kakuzo Okakura (Japanese Philosophy Edition)',
    category: 'books',
    categoryName: 'Books',
    price: 750.00,
    originalPrice: 900.00,
    rating: 4.8,
    reviewsCount: 228,
    image: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Timeless masterpiece exploring the aesthetic principles of Zen, Taoism, and the Japanese tea ceremony (Chado) as an art of everyday living.',
    features: ['Handcrafted Washi Paper Style Dustjacket', 'Unabridged Classic English & Japanese Text', 'Illustrations of Historical Tea Rooms', 'Compact Pocket Meditative Format'],
    inStock: true,
    sku: 'RJK-BK-604',
    isFeatured: false,
    badge: 'Classic Philosophy'
  },
  {
    id: 'prod-book-5',
    name: 'Tokyo Alleyways: Neon & Wood Architecture of Hidden Yokocho',
    category: 'books',
    categoryName: 'Books',
    price: 1590.00,
    originalPrice: 1850.00,
    rating: 4.9,
    reviewsCount: 185,
    image: 'https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?auto=format&fit=crop&w=700&q=80',
    images: [
      'https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?auto=format&fit=crop&w=700&q=80'
    ],
    description: 'Photographic voyage into the labyrinthine drinking alleys and Izakaya micro-bars of Shinjuku Golden Gai, Omoide Yokocho, and Yanaka.',
    features: ['240 High-Gloss Archival Color Plates', 'Bilingual English/Japanese Maps', 'Architecture Elevation Diagrams', 'Interviews with Master Bar Keepers'],
    inStock: true,
    sku: 'RJK-BK-605',
    isFeatured: false,
    badge: 'Architecture'
  }
];

export default products;
